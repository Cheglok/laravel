<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>News List</title>
</head>
<body>
<p>Navigation</p>
<ul>
    <li><a href="/hello">Hello</a></li>
    <li><a href="/news">News</a></li>
    <li><a href="/newsList">News list</a></li>
</ul>
<h2>Here will be news list</h2>
</body>
</html>
<?php /**PATH /home/vagrant/code/resources/views/newsList.blade.php ENDPATH**/ ?>