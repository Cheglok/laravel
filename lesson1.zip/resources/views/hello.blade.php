<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Hello</title>
</head>
<body>
<p>Navigation</p>
<ul>
    <li><a href="/hello">Hello</a></li>
    <li><a href="/news">News</a></li>
    <li><a href="/newsList">News list</a></li>
</ul>
<h2>I glad to see you on my first Laravel project main page</h2>
</body>
</html>
