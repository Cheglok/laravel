<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>News</title>
</head>
<body>
<p>Navigation</p>
<ul>
    <li><a href="/hello">Hello</a></li>
    <li><a href="/news">News</a></li>
    <li><a href="/newsList">News list</a></li>
</ul>
<h2>Вы находитесь на странице новости, это очень интересная новость, другие можно посмотреть по ссылке News list</h2>
</body>
</html>
